var group__ADC__Private__Functions =
[
    [ "Analog Watchdog configuration functions", "group__ADC__Group2.html", "group__ADC__Group2" ],
    [ "Initialization and Configuration functions", "group__ADC__Group1.html", "group__ADC__Group1" ],
    [ "Injected channels Configuration functions", "group__ADC__Group6.html", "group__ADC__Group6" ],
    [ "Interrupts and flags management functions", "group__ADC__Group7.html", "group__ADC__Group7" ],
    [ "Regular Channels Configuration functions", "group__ADC__Group4.html", "group__ADC__Group4" ],
    [ "Regular Channels DMA Configuration functions", "group__ADC__Group5.html", "group__ADC__Group5" ],
    [ "Temperature Sensor, Vrefint (Voltage Reference internal)", "group__ADC__Group3.html", "group__ADC__Group3" ]
];