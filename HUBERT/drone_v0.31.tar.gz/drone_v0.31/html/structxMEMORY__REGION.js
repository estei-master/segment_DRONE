var structxMEMORY__REGION =
[
    [ "pvBaseAddress", "structxMEMORY__REGION.html#a5c540d9e8ba79b50b9600f7225d41268", null ],
    [ "ulLengthInBytes", "structxMEMORY__REGION.html#a3bab560a2b429ca0430ec91ce759c9f8", null ],
    [ "ulParameters", "structxMEMORY__REGION.html#a9c337bc748fd9f212e8256d53d0cbec4", null ]
];