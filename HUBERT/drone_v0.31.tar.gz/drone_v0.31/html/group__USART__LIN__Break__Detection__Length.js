var group__USART__LIN__Break__Detection__Length =
[
    [ "IS_USART_LIN_BREAK_DETECT_LENGTH", "group__USART__LIN__Break__Detection__Length.html#gaa7a45d542b1df5da1160777ad4a80d72", null ],
    [ "USART_LINBreakDetectLength_10b", "group__USART__LIN__Break__Detection__Length.html#gacfd0aabae8774239440e828c961ac2a0", null ],
    [ "USART_LINBreakDetectLength_11b", "group__USART__LIN__Break__Detection__Length.html#gaf591cfcc859d67d71e6fa594eb5aec16", null ]
];