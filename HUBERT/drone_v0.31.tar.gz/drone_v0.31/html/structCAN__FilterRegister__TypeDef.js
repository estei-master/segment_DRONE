var structCAN__FilterRegister__TypeDef =
[
    [ "FR1", "structCAN__FilterRegister__TypeDef.html#a92036953ac673803fe001d843fea508b", null ],
    [ "FR2", "structCAN__FilterRegister__TypeDef.html#a7f7d80b45b7574463d7030fc8a464582", null ]
];