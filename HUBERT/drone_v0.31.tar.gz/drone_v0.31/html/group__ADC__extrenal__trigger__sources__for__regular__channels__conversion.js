var group__ADC__extrenal__trigger__sources__for__regular__channels__conversion =
[
    [ "ADC_ExternalTrigConv_Ext_IT11", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga98836a8cdc61e13a010d31cdee38bee0", null ],
    [ "ADC_ExternalTrigConv_T1_CC1", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga303f24361ea930f8214e9e68b63b244e", null ],
    [ "ADC_ExternalTrigConv_T1_CC2", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga8bf9fd9ad4e4c12ef41520ded2c3c332", null ],
    [ "ADC_ExternalTrigConv_T1_CC3", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga41ad03e2921f6de0fb75ae06d6046e63", null ],
    [ "ADC_ExternalTrigConv_T2_CC2", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#gadfeb40c1735b0ee50f8a5aafdd840cc6", null ],
    [ "ADC_ExternalTrigConv_T2_CC3", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga16ae1b335f2c2b4facf3d4bedc2ce27f", null ],
    [ "ADC_ExternalTrigConv_T2_CC4", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga2b4d6fe3412ce425b8b50a1ca59799aa", null ],
    [ "ADC_ExternalTrigConv_T2_TRGO", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga71119dd3f8970be2adf9b09f19e39b10", null ],
    [ "ADC_ExternalTrigConv_T3_CC1", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga3c73d5c8bb0f898dbbc74bcc536f6ec1", null ],
    [ "ADC_ExternalTrigConv_T3_TRGO", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga1cf4549534a00fe2f5527ad783204098", null ],
    [ "ADC_ExternalTrigConv_T4_CC4", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga8f6a764b7de878c2e09bbb0d1061d69c", null ],
    [ "ADC_ExternalTrigConv_T5_CC1", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga6bd1ad69cb455afeabf6759b640378d3", null ],
    [ "ADC_ExternalTrigConv_T5_CC2", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#gaa0b2758322ef54acc2753128f6b024d1", null ],
    [ "ADC_ExternalTrigConv_T5_CC3", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga95b58981aff35d6d5fa229925cd6315d", null ],
    [ "ADC_ExternalTrigConv_T8_CC1", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#ga97af875d12e77a67e84f3aaf1f8033ed", null ],
    [ "ADC_ExternalTrigConv_T8_TRGO", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#gab26d94590d47ae6ec46841652741abf3", null ],
    [ "IS_ADC_EXT_TRIG", "group__ADC__extrenal__trigger__sources__for__regular__channels__conversion.html#gac74e6054adbedd72822cacde69105318", null ]
];