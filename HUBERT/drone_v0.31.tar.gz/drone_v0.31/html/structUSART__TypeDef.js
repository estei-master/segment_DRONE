var structUSART__TypeDef =
[
    [ "BRR", "structUSART__TypeDef.html#af0ba3d82d524fddbe0fb3309788e2954", null ],
    [ "CR1", "structUSART__TypeDef.html#a61400ce239355b62aa25c95fcc18a5e1", null ],
    [ "CR2", "structUSART__TypeDef.html#a2a3e81bd118d1bc52d24a0b0772e6a0c", null ],
    [ "CR3", "structUSART__TypeDef.html#a9651ce2df8eec57b9cab2f27f6dbf3e1", null ],
    [ "DR", "structUSART__TypeDef.html#a0a1acc0425516ff7969709d118b96a3b", null ],
    [ "GTPR", "structUSART__TypeDef.html#a26f8b74978e03c8a4c99c9395a6a524d", null ],
    [ "RESERVED0", "structUSART__TypeDef.html#a149feba01f9c4a49570c6d88619f504f", null ],
    [ "RESERVED1", "structUSART__TypeDef.html#a8249a3955aace28d92109b391311eb30", null ],
    [ "RESERVED2", "structUSART__TypeDef.html#a5573848497a716a9947fd87487709feb", null ],
    [ "RESERVED3", "structUSART__TypeDef.html#a6c3b31022e6f59b800e9f5cc2a89d54c", null ],
    [ "RESERVED4", "structUSART__TypeDef.html#aa0223808025f5bf9c056185038c9d545", null ],
    [ "RESERVED5", "structUSART__TypeDef.html#abd36010ac282682d1f3c641b183b1b6f", null ],
    [ "RESERVED6", "structUSART__TypeDef.html#aab502dde158ab7da8e7823d1f8a06edb", null ],
    [ "SR", "structUSART__TypeDef.html#a44962ea5442d203bf4954035d1bfeb9d", null ]
];