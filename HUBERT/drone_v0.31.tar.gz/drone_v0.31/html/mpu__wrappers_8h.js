var mpu__wrappers_8h =
[
    [ "portUSING_MPU_WRAPPERS", "mpu__wrappers_8h.html#a63d7ba028eb2432720bb5c7d626a8d7e", null ],
    [ "PRIVILEGED_DATA", "mpu__wrappers_8h.html#a56a0b54ca924c56d192d4389ba585ed5", null ],
    [ "PRIVILEGED_FUNCTION", "mpu__wrappers_8h.html#a4785c4f4a8c04b835139dcc2a6682078", null ]
];