var group__DMA__priority__level =
[
    [ "DMA_Priority_High", "group__DMA__priority__level.html#gae2441c0b4d4ba9945a6f4f7d08045a8e", null ],
    [ "DMA_Priority_Low", "group__DMA__priority__level.html#gaf414e0aa8dd42aee6f83f88ab6175179", null ],
    [ "DMA_Priority_Medium", "group__DMA__priority__level.html#ga8e0d4a958f4288c6c759945789490f38", null ],
    [ "DMA_Priority_VeryHigh", "group__DMA__priority__level.html#gadccd2f8b2ac24ba4fd485dd5b9b48671", null ],
    [ "IS_DMA_PRIORITY", "group__DMA__priority__level.html#gaa1cae2ab458948511596467c87cd02b6", null ]
];