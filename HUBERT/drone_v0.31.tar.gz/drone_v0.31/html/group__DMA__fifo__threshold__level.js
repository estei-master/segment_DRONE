var group__DMA__fifo__threshold__level =
[
    [ "DMA_FIFOThreshold_1QuarterFull", "group__DMA__fifo__threshold__level.html#gacc98384bbba43a9c4f70b448518acfe4", null ],
    [ "DMA_FIFOThreshold_3QuartersFull", "group__DMA__fifo__threshold__level.html#ga6f041008fce4bb341f9a518d803a308b", null ],
    [ "DMA_FIFOThreshold_Full", "group__DMA__fifo__threshold__level.html#ga9f1008e0df7d41d910ed89d7e0872e69", null ],
    [ "DMA_FIFOThreshold_HalfFull", "group__DMA__fifo__threshold__level.html#ga626b546865960343fdcfdf33ac8ceb03", null ],
    [ "IS_DMA_FIFO_THRESHOLD", "group__DMA__fifo__threshold__level.html#gaeafc0d9e327d6e5b26cd37f6744b232f", null ]
];