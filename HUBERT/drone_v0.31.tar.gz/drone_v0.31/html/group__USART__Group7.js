var group__USART__Group7 =
[
    [ "USART_IrDACmd", "group__USART__Group7.html#gabff56ebb494fdfadcc6ef4fe9ac8dd24", null ],
    [ "USART_IrDAConfig", "group__USART__Group7.html#ga81a0cd36199040bf6d266b57babd678e", null ]
];