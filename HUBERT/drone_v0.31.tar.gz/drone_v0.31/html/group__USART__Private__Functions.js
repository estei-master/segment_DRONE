var group__USART__Private__Functions =
[
    [ "DMA transfers management functions", "group__USART__Group8.html", "group__USART__Group8" ],
    [ "Data transfers functions", "group__USART__Group2.html", "group__USART__Group2" ],
    [ "Halfduplex mode function", "group__USART__Group5.html", "group__USART__Group5" ],
    [ "Initialization and Configuration functions", "group__USART__Group1.html", "group__USART__Group1" ],
    [ "Interrupts and flags management functions", "group__USART__Group9.html", "group__USART__Group9" ],
    [ "IrDA mode functions", "group__USART__Group7.html", "group__USART__Group7" ],
    [ "LIN mode functions", "group__USART__Group4.html", "group__USART__Group4" ],
    [ "MultiProcessor Communication functions", "group__USART__Group3.html", "group__USART__Group3" ],
    [ "Smartcard mode functions", "group__USART__Group6.html", "group__USART__Group6" ]
];