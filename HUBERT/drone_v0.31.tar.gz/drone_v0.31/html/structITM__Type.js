var structITM__Type =
[
    [ "PORT", "structITM__Type.html#aca2b00738a4a346efcd8325e18fcfa8a", null ],
    [ "RESERVED0", "structITM__Type.html#a498ca2f25075b26fd57d1f66d976fe8c", null ],
    [ "RESERVED1", "structITM__Type.html#ae5c625673da1df1777833e51754c525b", null ],
    [ "RESERVED2", "structITM__Type.html#a391748a705084dd61c4a9f56d456a12c", null ],
    [ "TCR", "structITM__Type.html#ae9dd9282fab299d0cd6e119564688e53", null ],
    [ "TER", "structITM__Type.html#a8ffb3c6b706b03334f6fe37ef5d8b165", null ],
    [ "TPR", "structITM__Type.html#a72bb9b7d61fe3262cd2a6070a7bd5b69", null ],
    [ "u16", "structITM__Type.html#ae8d499140220fa6d4eab1da7262bf08e", null ],
    [ "u32", "structITM__Type.html#acaf6d0e14a3d4b541c624913b4a1931e", null ],
    [ "u8", "structITM__Type.html#a0374c0b98ab9de6f71fabff7412df832", null ]
];