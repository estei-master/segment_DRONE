var structSDIO__TypeDef =
[
    [ "ARG", "structSDIO__TypeDef.html#a07d4e63efcbde252c667e64a8d818aa9", null ],
    [ "CLKCR", "structSDIO__TypeDef.html#aa94197378e20fc739d269be49d9c5d40", null ],
    [ "CMD", "structSDIO__TypeDef.html#adcf812cbe5147d300507d59d4a55935d", null ],
    [ "DCOUNT", "structSDIO__TypeDef.html#a4273e2b5aeb7bdf1006909b1a2b59bc8", null ],
    [ "DCTRL", "structSDIO__TypeDef.html#a96a3d1a050982fccc23c2e6dbe0de068", null ],
    [ "DLEN", "structSDIO__TypeDef.html#a612edc78d2fa6288392f8ea32c36f7fb", null ],
    [ "DTIMER", "structSDIO__TypeDef.html#a1dd219eaeee8d9def822da843028bd02", null ],
    [ "FIFO", "structSDIO__TypeDef.html#a68bef1da5fd164cf0f884b4209670dc8", null ],
    [ "FIFOCNT", "structSDIO__TypeDef.html#ab27b78e19f487c845437c29812eecca7", null ],
    [ "ICR", "structSDIO__TypeDef.html#a0a8c8230846fd8ff154b9fde8dfa0399", null ],
    [ "MASK", "structSDIO__TypeDef.html#a5c955643593b4aedbe9f84f054d26522", null ],
    [ "POWER", "structSDIO__TypeDef.html#a65bff76f3af24c37708a1006d54720c7", null ],
    [ "RESERVED0", "structSDIO__TypeDef.html#a8be676577db129a84a9a2689519a8502", null ],
    [ "RESERVED1", "structSDIO__TypeDef.html#a2d531df35272b1f3d787e5726ed5c52c", null ],
    [ "RESP1", "structSDIO__TypeDef.html#a7b0ee0dc541683266dfab6335abca891", null ],
    [ "RESP2", "structSDIO__TypeDef.html#a4d99c78dffdb6e81e8f6b7abec263419", null ],
    [ "RESP3", "structSDIO__TypeDef.html#a3da04fbdd44f48a1840e5e0a6295f3cf", null ],
    [ "RESP4", "structSDIO__TypeDef.html#ac760383de212de696f504e744c6fca7e", null ],
    [ "RESPCMD", "structSDIO__TypeDef.html#aad371db807e2db4a2edf05b3f2f4b6cd", null ],
    [ "STA", "structSDIO__TypeDef.html#a7520cdf6f3df68c2f147bdd87fb8a96f", null ]
];