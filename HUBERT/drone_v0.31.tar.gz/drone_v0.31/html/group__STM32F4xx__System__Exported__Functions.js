var group__STM32F4xx__System__Exported__Functions =
[
    [ "SystemCoreClockUpdate", "group__STM32F4xx__System__Exported__Functions.html#gae0c36a9591fe6e9c45ecb21a794f0f0f", null ],
    [ "SystemInit", "group__STM32F4xx__System__Exported__Functions.html#ga93f514700ccf00d08dbdcff7f1224eb2", null ]
];