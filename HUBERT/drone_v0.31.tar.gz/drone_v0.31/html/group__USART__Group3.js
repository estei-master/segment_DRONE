var group__USART__Group3 =
[
    [ "USART_ReceiverWakeUpCmd", "group__USART__Group3.html#gac27b78ce445a16fe33851d2f87781c02", null ],
    [ "USART_SetAddress", "group__USART__Group3.html#ga65ec9928817f3f031dd9a4dfc95d6666", null ],
    [ "USART_WakeUpConfig", "group__USART__Group3.html#ga4965417c2412c36e462fcad50a8d5393", null ]
];