var group__ADC__regular__length =
[
    [ "IS_ADC_REGULAR_LENGTH", "group__ADC__regular__length.html#ga1ea82167f6dccdef1d160675f4534584", null ]
];