var group__DMA__fifo__direct__mode =
[
    [ "DMA_FIFOMode_Disable", "group__DMA__fifo__direct__mode.html#gadad9e503fa9867a981e3090d333483d7", null ],
    [ "DMA_FIFOMode_Enable", "group__DMA__fifo__direct__mode.html#ga482bc2af420602d1a8c2aa35049a3857", null ],
    [ "IS_DMA_FIFO_MODE_STATE", "group__DMA__fifo__direct__mode.html#gadb90a893aeb49fd4bc14af750af3837c", null ]
];