var group__ADC__sampling__times =
[
    [ "ADC_SampleTime_112Cycles", "group__ADC__sampling__times.html#ga1b98913dec7a22c54f0749ce254f9796", null ],
    [ "ADC_SampleTime_144Cycles", "group__ADC__sampling__times.html#ga7a873e1b0768c76aba7d7051f79371ce", null ],
    [ "ADC_SampleTime_15Cycles", "group__ADC__sampling__times.html#gae8cc5b72a8732467ebbd4a2c208352de", null ],
    [ "ADC_SampleTime_28Cycles", "group__ADC__sampling__times.html#gad9b45e11b76b7046eddf67f72e2ad622", null ],
    [ "ADC_SampleTime_3Cycles", "group__ADC__sampling__times.html#ga7b89fd620d7f7d361a9e7af3713cca0e", null ],
    [ "ADC_SampleTime_480Cycles", "group__ADC__sampling__times.html#ga35735ec1c17518cdf28c36ac8a012db9", null ],
    [ "ADC_SampleTime_56Cycles", "group__ADC__sampling__times.html#ga8bf24e20be542f9d69d7ed86bb138122", null ],
    [ "ADC_SampleTime_84Cycles", "group__ADC__sampling__times.html#gae48f94881114c1f042fadb4322a9d1b2", null ],
    [ "IS_ADC_SAMPLE_TIME", "group__ADC__sampling__times.html#ga30e0307fa009e1c383d3047b48e94644", null ]
];