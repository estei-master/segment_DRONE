var structdroneTelemeterWrapper =
[
    [ "xTelemeterData", "structdroneTelemeterWrapper.html#acde4f0df38902e736eea06c729fc136c", null ],
    [ "xUpdateTime", "structdroneTelemeterWrapper.html#a3eb93eae26238af430cf63ce6d3d5b72", null ]
];