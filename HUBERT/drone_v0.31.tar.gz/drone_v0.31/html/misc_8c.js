var misc_8c =
[
    [ "AIRCR_VECTKEY_MASK", "misc_8c.html#gad6905141fba3a2d8d5570db40805dc6a", null ],
    [ "NVIC_Init", "misc_8c.html#ga4ab373ed0870c06fca5eb51d639adf41", null ],
    [ "NVIC_PriorityGroupConfig", "misc_8c.html#gadfb1f34f803ce54c976643db8c484442", null ],
    [ "NVIC_SetVectorTable", "misc_8c.html#ga1145208ad70edfc2fab19b8b8ef1b1a1", null ],
    [ "NVIC_SystemLPConfig", "misc_8c.html#gae21011c5232f5b8f366acbecd12a1d4a", null ],
    [ "SysTick_CLKSourceConfig", "misc_8c.html#ga2777d255bb06ad62bb6372a9db1ff385", null ]
];