var unionIPSR__Type =
[
    [ "_reserved0", "unionIPSR__Type.html#ac8a6a13838a897c8d0b8bc991bbaf7c1", null ],
    [ "b", "unionIPSR__Type.html#a3758147356a15906221a5625a27d9048", null ],
    [ "ISR", "unionIPSR__Type.html#ad502ba7dbb2aab5f87c782b28f02622d", null ],
    [ "w", "unionIPSR__Type.html#ad0fb62e7a08e70fc5e0a76b67809f84b", null ]
];