var group__MISC__SysTick__clock__source =
[
    [ "IS_SYSTICK_CLK_SOURCE", "group__MISC__SysTick__clock__source.html#ga22d6291f6aed29442cf4cd9098fa0784", null ],
    [ "SysTick_CLKSource_HCLK", "group__MISC__SysTick__clock__source.html#ga8a885ce2632ad4c35e229bb7c6e60191", null ],
    [ "SysTick_CLKSource_HCLK_Div8", "group__MISC__SysTick__clock__source.html#ga545c387ce43db90f15faad5f354f890d", null ]
];