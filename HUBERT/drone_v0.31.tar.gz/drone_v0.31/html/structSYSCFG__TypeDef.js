var structSYSCFG__TypeDef =
[
    [ "CMPCR", "structSYSCFG__TypeDef.html#a08ddbac546fa9928256654d31255c8c3", null ],
    [ "EXTICR", "structSYSCFG__TypeDef.html#a52f7bf8003ba69d66a4e86dea6eeab65", null ],
    [ "MEMRMP", "structSYSCFG__TypeDef.html#ab36c409d0a009e3ce5a89ac55d3ff194", null ],
    [ "PMC", "structSYSCFG__TypeDef.html#a2130abf1fefb63ce4c4b138fd8c9822a", null ],
    [ "RESERVED", "structSYSCFG__TypeDef.html#afaf27b66c1edc60064db3fa6e693fb59", null ]
];