var group__ADC__analog__watchdog__selection =
[
    [ "ADC_AnalogWatchdog_AllInjecEnable", "group__ADC__analog__watchdog__selection.html#gae4d6a7ebb136d924f0c8bad2cbac0574", null ],
    [ "ADC_AnalogWatchdog_AllRegAllInjecEnable", "group__ADC__analog__watchdog__selection.html#ga25a299f4493aaae316521351198df084", null ],
    [ "ADC_AnalogWatchdog_AllRegEnable", "group__ADC__analog__watchdog__selection.html#ga37f08e1a4a452a2c148341b3cfcdeb1e", null ],
    [ "ADC_AnalogWatchdog_None", "group__ADC__analog__watchdog__selection.html#ga91f69979e0e449fef5a8b225a21e3eb9", null ],
    [ "ADC_AnalogWatchdog_SingleInjecEnable", "group__ADC__analog__watchdog__selection.html#gaa9904271617ab69593ac68ae540047fb", null ],
    [ "ADC_AnalogWatchdog_SingleRegEnable", "group__ADC__analog__watchdog__selection.html#ga2975552a752f44085d9da54b4e76121e", null ],
    [ "ADC_AnalogWatchdog_SingleRegOrInjecEnable", "group__ADC__analog__watchdog__selection.html#gaffd35fc6ceb226ec3fb61fb52227820c", null ],
    [ "IS_ADC_ANALOG_WATCHDOG", "group__ADC__analog__watchdog__selection.html#ga53ffa30f756569194342bfba80165544", null ]
];