var group__DAC__output__buffer =
[
    [ "DAC_OutputBuffer_Disable", "group__DAC__output__buffer.html#gad41f919d7141398cfdedf8218ce64450", null ],
    [ "DAC_OutputBuffer_Enable", "group__DAC__output__buffer.html#gab3f92803a8b6bc5fb3e4859908b5161f", null ],
    [ "IS_DAC_OUTPUT_BUFFER_STATE", "group__DAC__output__buffer.html#gaa5a56816d641129fb62d11133c9dcccd", null ]
];