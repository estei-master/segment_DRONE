var group__ADC__Prescaler =
[
    [ "ADC_Prescaler_Div2", "group__ADC__Prescaler.html#gaedf3593442796684ace09bce1c6a5dde", null ],
    [ "ADC_Prescaler_Div4", "group__ADC__Prescaler.html#ga8835521adcb2239c0bc0eec8f5eb8711", null ],
    [ "ADC_Prescaler_Div6", "group__ADC__Prescaler.html#ga49cb7f0ac571b5a9105ac7c037559d63", null ],
    [ "ADC_Prescaler_Div8", "group__ADC__Prescaler.html#gae56f649c15bfb0cbb87f6456a320664f", null ],
    [ "IS_ADC_PRESCALER", "group__ADC__Prescaler.html#gae69f71c595aef04fe0c0bbe9100d28ca", null ]
];