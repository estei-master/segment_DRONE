var group__ADC__external__trigger__edge__for__regular__channels__conversion =
[
    [ "ADC_ExternalTrigConvEdge_Falling", "group__ADC__external__trigger__edge__for__regular__channels__conversion.html#gaff5f4b6ab1dd64a9828c7e9137cc4a92", null ],
    [ "ADC_ExternalTrigConvEdge_None", "group__ADC__external__trigger__edge__for__regular__channels__conversion.html#ga43fb008d4ac755bf5d359e04614d413b", null ],
    [ "ADC_ExternalTrigConvEdge_Rising", "group__ADC__external__trigger__edge__for__regular__channels__conversion.html#gac40e6cec3ca4a07c2e3d652cd1488d99", null ],
    [ "ADC_ExternalTrigConvEdge_RisingFalling", "group__ADC__external__trigger__edge__for__regular__channels__conversion.html#gad2bbb99714b093437e3d3aafed30518a", null ],
    [ "IS_ADC_EXT_TRIG_EDGE", "group__ADC__external__trigger__edge__for__regular__channels__conversion.html#gad4e7bd22759d723c50cda223ef2b9b82", null ]
];