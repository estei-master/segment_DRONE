var group__ADC__external__trigger__edge__for__injected__channels__conversion =
[
    [ "ADC_ExternalTrigInjecConvEdge_Falling", "group__ADC__external__trigger__edge__for__injected__channels__conversion.html#ga021b91cd4d06a2c918d364c01296606d", null ],
    [ "ADC_ExternalTrigInjecConvEdge_None", "group__ADC__external__trigger__edge__for__injected__channels__conversion.html#gadded0427c7ab2c1b83bff0950e7bc159", null ],
    [ "ADC_ExternalTrigInjecConvEdge_Rising", "group__ADC__external__trigger__edge__for__injected__channels__conversion.html#gab7238752eca96a099d39a472550675c1", null ],
    [ "ADC_ExternalTrigInjecConvEdge_RisingFalling", "group__ADC__external__trigger__edge__for__injected__channels__conversion.html#ga8276098b68c3e16638cd742d1593e78e", null ],
    [ "IS_ADC_EXT_INJEC_TRIG_EDGE", "group__ADC__external__trigger__edge__for__injected__channels__conversion.html#ga1071d8b9c241b032c87c0f858d8de517", null ]
];