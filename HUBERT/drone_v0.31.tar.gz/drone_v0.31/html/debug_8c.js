var debug_8c =
[
    [ "debugUART_MAX_STRING_LENGHT", "debug_8c.html#a4e32c217fc798558c5ae89d0356a3592", null ],
    [ "ulDebugMsg", "debug_8c.html#a2d3888037c45cc6599c5ab1dea029e02", null ],
    [ "vDebugUARTInit", "debug_8c.html#a1725f43d8313e898e39fa36b535ea337", null ],
    [ "vDebugUARTPutchar", "debug_8c.html#a852a17e70fc313d1bbf8130b4df1fb7e", null ]
];