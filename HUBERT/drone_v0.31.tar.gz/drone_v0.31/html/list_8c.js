var list_8c =
[
    [ "vListInitialise", "list_8c.html#acc831631f04ca3f6fef79b0175f6d6e1", null ],
    [ "vListInitialiseItem", "list_8c.html#aa0c6c2804f1673b95f781a795ebf96d8", null ],
    [ "vListInsert", "list_8c.html#ae0c352207d36c7ba3fa1b970b1eadd51", null ],
    [ "vListInsertEnd", "list_8c.html#aa234bf74629ff34fbd8494a0f0112b42", null ],
    [ "vListRemove", "list_8c.html#a6c083a9d7103fca1c9abd0de20839651", null ]
];