var group__ADC__Direct__memory__access__mode__for__multi__mode =
[
    [ "ADC_DMAAccessMode_1", "group__ADC__Direct__memory__access__mode__for__multi__mode.html#gaa926422d2fe55fad4aef43a447a1db4e", null ],
    [ "ADC_DMAAccessMode_2", "group__ADC__Direct__memory__access__mode__for__multi__mode.html#ga8033fd7a73a066bdd42ebd3885d54b71", null ],
    [ "ADC_DMAAccessMode_3", "group__ADC__Direct__memory__access__mode__for__multi__mode.html#ga88e1a38c09ba9e91a70756a46f3a4870", null ],
    [ "ADC_DMAAccessMode_Disabled", "group__ADC__Direct__memory__access__mode__for__multi__mode.html#ga454e557ea6e3c54d913cfa6cfbd10d8d", null ],
    [ "IS_ADC_DMA_ACCESS_MODE", "group__ADC__Direct__memory__access__mode__for__multi__mode.html#gacc017b6a9b3ae942307fa95242cc4aa1", null ]
];