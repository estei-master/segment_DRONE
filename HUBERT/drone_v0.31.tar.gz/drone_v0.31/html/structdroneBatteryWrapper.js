var structdroneBatteryWrapper =
[
    [ "ulPowerLvl", "structdroneBatteryWrapper.html#ace99ab7d1b237062343841952bc4b011", null ],
    [ "xUpdateTime", "structdroneBatteryWrapper.html#a3eb93eae26238af430cf63ce6d3d5b72", null ]
];