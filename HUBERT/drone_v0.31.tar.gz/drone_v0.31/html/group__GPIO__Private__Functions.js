var group__GPIO__Private__Functions =
[
    [ "GPIO Alternate functions configuration function", "group__GPIO__Group3.html", "group__GPIO__Group3" ],
    [ "GPIO Read and Write", "group__GPIO__Group2.html", "group__GPIO__Group2" ],
    [ "Initialization and Configuration", "group__GPIO__Group1.html", "group__GPIO__Group1" ]
];