var group__DAC__trigger__selection =
[
    [ "DAC_Trigger_Ext_IT9", "group__DAC__trigger__selection.html#ga67c15b2c26246a2304f9db28e25adcc4", null ],
    [ "DAC_Trigger_None", "group__DAC__trigger__selection.html#ga7849138e043267668d755390d923e4ba", null ],
    [ "DAC_Trigger_Software", "group__DAC__trigger__selection.html#gadef77bb8bbd109232900902402ef637f", null ],
    [ "DAC_Trigger_T2_TRGO", "group__DAC__trigger__selection.html#ga3bfbff1e03af1fd17a57a43e57420fe6", null ],
    [ "DAC_Trigger_T4_TRGO", "group__DAC__trigger__selection.html#ga58ccb2de3d22d66ee975152f5edb330a", null ],
    [ "DAC_Trigger_T5_TRGO", "group__DAC__trigger__selection.html#ga35352cebfd1ae8a3d63e374a5d86a85d", null ],
    [ "DAC_Trigger_T6_TRGO", "group__DAC__trigger__selection.html#ga083307783678a2f1d3066db57dc84cfe", null ],
    [ "DAC_Trigger_T7_TRGO", "group__DAC__trigger__selection.html#ga9b92d497746be54af46ae4e9c1fc4a6f", null ],
    [ "DAC_Trigger_T8_TRGO", "group__DAC__trigger__selection.html#ga756700c6621eadb807e21a16966580a0", null ],
    [ "IS_DAC_TRIGGER", "group__DAC__trigger__selection.html#ga4409b79639e6ae3b1f0ed61a33c810a3", null ]
];