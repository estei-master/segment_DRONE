var group__USART__Clock__Polarity =
[
    [ "IS_USART_CPOL", "group__USART__Clock__Polarity.html#ga833e9d2e85ab84658c7a7c18bd0bc8b9", null ],
    [ "USART_CPOL_High", "group__USART__Clock__Polarity.html#ga4ba6946dd9f0b4fd38115f24798c210f", null ],
    [ "USART_CPOL_Low", "group__USART__Clock__Polarity.html#ga194d60b47d8042d39e843c52f3a6aa1a", null ]
];