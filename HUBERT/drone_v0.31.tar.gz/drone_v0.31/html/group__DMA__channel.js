var group__DMA__channel =
[
    [ "DMA_Channel_0", "group__DMA__channel.html#ga4979fc18bd59701dec52c8fa89b5edb2", null ],
    [ "DMA_Channel_1", "group__DMA__channel.html#gacad41f71e3a940abd495b0aab3b4e8cb", null ],
    [ "DMA_Channel_2", "group__DMA__channel.html#ga6b5d9fcfd72335777ce2796af6300574", null ],
    [ "DMA_Channel_3", "group__DMA__channel.html#gaf835103c99f21d1b1c04d5c98471c1d5", null ],
    [ "DMA_Channel_4", "group__DMA__channel.html#gac8a40bf3a421b434177e988263a3d787", null ],
    [ "DMA_Channel_5", "group__DMA__channel.html#gae3dd5d28def40846aea8e3013d63311b", null ],
    [ "DMA_Channel_6", "group__DMA__channel.html#ga141e89570dabba4f778e8e8df80e7812", null ],
    [ "DMA_Channel_7", "group__DMA__channel.html#ga14f1265827ce49dad5075986118cc542", null ],
    [ "IS_DMA_CHANNEL", "group__DMA__channel.html#gac7f4709d9244f25b853789d888a74d46", null ]
];