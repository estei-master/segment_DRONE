var structxMINI__LIST__ITEM =
[
    [ "pxNext", "structxMINI__LIST__ITEM.html#a49efbbdf7a776a0bd9fae32645a29a71", null ],
    [ "pxPrevious", "structxMINI__LIST__ITEM.html#acb050b62f50f97ea821ae2fc604f39a9", null ],
    [ "xItemValue", "structxMINI__LIST__ITEM.html#a83bf16246a7893527d5ea5d2aa7cc4bf", null ]
];