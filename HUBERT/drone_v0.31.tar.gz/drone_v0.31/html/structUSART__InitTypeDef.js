var structUSART__InitTypeDef =
[
    [ "USART_BaudRate", "structUSART__InitTypeDef.html#a8712e31ee9d088d83c84d38d88c6af0b", null ],
    [ "USART_HardwareFlowControl", "structUSART__InitTypeDef.html#ab41fe3b9f5cb4ed89be23bff0a1f4114", null ],
    [ "USART_Mode", "structUSART__InitTypeDef.html#a1a581f24451bf5a4a210bab8d68998e2", null ],
    [ "USART_Parity", "structUSART__InitTypeDef.html#a4edcc84644c8553a1a6e841c48ea8413", null ],
    [ "USART_StopBits", "structUSART__InitTypeDef.html#aa58409990a6a0bc99f432eb90e204c0f", null ],
    [ "USART_WordLength", "structUSART__InitTypeDef.html#aa1248b67914e095c0de768223eea9328", null ]
];