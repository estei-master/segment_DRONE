var group__ADC__Group5 =
[
    [ "ADC_DMACmd", "group__ADC__Group5.html#gac5881d5995818001584b27b137a8dbcb", null ],
    [ "ADC_DMARequestAfterLastTransferCmd", "group__ADC__Group5.html#ga912fd3e923ae4435621724e1bbc52729", null ],
    [ "ADC_MultiModeDMARequestAfterLastTransferCmd", "group__ADC__Group5.html#ga40f2be2edf2a33fc15f4a5933b562970", null ]
];