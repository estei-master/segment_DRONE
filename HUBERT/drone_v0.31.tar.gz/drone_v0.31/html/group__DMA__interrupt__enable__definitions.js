var group__DMA__interrupt__enable__definitions =
[
    [ "DMA_IT_DME", "group__DMA__interrupt__enable__definitions.html#ga71137443f7bdced1ee80697596e9ea98", null ],
    [ "DMA_IT_FE", "group__DMA__interrupt__enable__definitions.html#ga93164ec039fc5579662c382e68d7d13f", null ],
    [ "DMA_IT_HT", "group__DMA__interrupt__enable__definitions.html#gadf11c572b9797e04a14b105fdc2e5f66", null ],
    [ "DMA_IT_TC", "group__DMA__interrupt__enable__definitions.html#ga06e83dd277e0d3e5635cf8ce8dfd6e16", null ],
    [ "DMA_IT_TE", "group__DMA__interrupt__enable__definitions.html#gaf9d92649d2a0146f663ff253d8f3b59e", null ],
    [ "IS_DMA_CONFIG_IT", "group__DMA__interrupt__enable__definitions.html#ga47f6af7da302c19aba24516037d305e7", null ]
];