var group__ADC__thresholds =
[
    [ "IS_ADC_THRESHOLD", "group__ADC__thresholds.html#gaa71cdff6dafddfccff8a7e88768bfb54", null ]
];