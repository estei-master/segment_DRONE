var group__DMA__memory__targets__definitions =
[
    [ "DMA_Memory_0", "group__DMA__memory__targets__definitions.html#gadb576bccef5f2fc65fe9b451033bdc95", null ],
    [ "DMA_Memory_1", "group__DMA__memory__targets__definitions.html#ga6d1e13631e4ef9a013d078e613fd7fd5", null ],
    [ "IS_DMA_CURRENT_MEM", "group__DMA__memory__targets__definitions.html#ga87d6abab18d2b4bb86db909854cc1f02", null ]
];