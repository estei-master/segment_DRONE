var structIWDG__TypeDef =
[
    [ "KR", "structIWDG__TypeDef.html#a2f692354bde770f2a5e3e1b294ec064b", null ],
    [ "PR", "structIWDG__TypeDef.html#af8d25514079514d38c104402f46470af", null ],
    [ "RLR", "structIWDG__TypeDef.html#a7015e1046dbd3ea8783b33dc11a69e52", null ],
    [ "SR", "structIWDG__TypeDef.html#af6aca2bbd40c0fb6df7c3aebe224a360", null ]
];