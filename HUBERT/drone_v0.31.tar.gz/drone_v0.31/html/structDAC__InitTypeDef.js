var structDAC__InitTypeDef =
[
    [ "DAC_LFSRUnmask_TriangleAmplitude", "structDAC__InitTypeDef.html#aff0a3e0149873939ded70bc466c85dc2", null ],
    [ "DAC_OutputBuffer", "structDAC__InitTypeDef.html#a22d062287d8cbba2342585ea7944f61d", null ],
    [ "DAC_Trigger", "structDAC__InitTypeDef.html#ae1edfee233aee962b357cbc3994b330b", null ],
    [ "DAC_WaveGeneration", "structDAC__InitTypeDef.html#a3dfc2e2197154ed20469e57ccff591d3", null ]
];