var group__GPIO__Legacy =
[
    [ "GPIO_AF_OTG1_FS", "group__GPIO__Legacy.html#gaddd737997abcd1154c0998b22333b579", null ],
    [ "GPIO_AF_OTG2_FS", "group__GPIO__Legacy.html#ga85e574d8321b9d9aaa2790351b4f0c1e", null ],
    [ "GPIO_AF_OTG2_HS", "group__GPIO__Legacy.html#ga54715298b3dc7e843429fd3e24d42cd4", null ],
    [ "GPIO_Mode_AIN", "group__GPIO__Legacy.html#gadf4dafa8caa4e91d2bee996c4bfdf8cc", null ]
];