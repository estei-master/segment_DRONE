var structCAN__FIFOMailBox__TypeDef =
[
    [ "RDHR", "structCAN__FIFOMailBox__TypeDef.html#a7f11f42ba9d3bc5cd4a4f5ea0214608e", null ],
    [ "RDLR", "structCAN__FIFOMailBox__TypeDef.html#ae1c569688eedd49219cd505b9c22121b", null ],
    [ "RDTR", "structCAN__FIFOMailBox__TypeDef.html#a9563d8a88d0db403b8357331bea83a2e", null ],
    [ "RIR", "structCAN__FIFOMailBox__TypeDef.html#a0acc8eb90b17bef5b9e03c7ddaacfb0b", null ]
];