var group__USART__Group4 =
[
    [ "USART_LINBreakDetectLengthConfig", "group__USART__Group4.html#ga7bc2d291831cbc5e53e73337308029b5", null ],
    [ "USART_LINCmd", "group__USART__Group4.html#ga9fdd6296f4ca4acdfcbd58bf56bd4185", null ],
    [ "USART_SendBreak", "group__USART__Group4.html#ga39a3d33e23ee28529fa8f7259ce6811e", null ]
];