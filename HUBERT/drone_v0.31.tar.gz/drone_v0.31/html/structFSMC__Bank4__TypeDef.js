var structFSMC__Bank4__TypeDef =
[
    [ "PATT4", "structFSMC__Bank4__TypeDef.html#a955cad1aab7fb2d5b6e216cb29b5e7e2", null ],
    [ "PCR4", "structFSMC__Bank4__TypeDef.html#a2f02e7acfbd7e549ede84633215eb6a1", null ],
    [ "PIO4", "structFSMC__Bank4__TypeDef.html#ac53cd7a08093a4ae8f4de4bcff67a64f", null ],
    [ "PMEM4", "structFSMC__Bank4__TypeDef.html#a3f82cc749845fb0dd7dfa8121d96b663", null ],
    [ "SR4", "structFSMC__Bank4__TypeDef.html#a8218d6e11dae5d4468c69303dec0b4fc", null ]
];