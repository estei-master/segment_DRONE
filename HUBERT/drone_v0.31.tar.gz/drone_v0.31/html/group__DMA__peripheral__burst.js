var group__DMA__peripheral__burst =
[
    [ "DMA_PeripheralBurst_INC16", "group__DMA__peripheral__burst.html#ga04ff56ff0a2a5470fc2c4817be4213c2", null ],
    [ "DMA_PeripheralBurst_INC4", "group__DMA__peripheral__burst.html#gaa8eba5161b3927f1ffb81157f3e39b71", null ],
    [ "DMA_PeripheralBurst_INC8", "group__DMA__peripheral__burst.html#gaf04ba122268e0f54085ca8e45410fe69", null ],
    [ "DMA_PeripheralBurst_Single", "group__DMA__peripheral__burst.html#ga524cdc5efb8978b586637f35e38a850b", null ],
    [ "IS_DMA_PERIPHERAL_BURST", "group__DMA__peripheral__burst.html#ga7c60961178e2a32e9e364a220a8aca88", null ]
];