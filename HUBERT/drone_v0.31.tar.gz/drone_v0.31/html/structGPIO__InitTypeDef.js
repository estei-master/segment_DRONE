var structGPIO__InitTypeDef =
[
    [ "GPIO_Mode", "structGPIO__InitTypeDef.html#a0c7e8901d8b511bbb8c3b153f705dbba", null ],
    [ "GPIO_OType", "structGPIO__InitTypeDef.html#a321a268abbed3d2f01c27383e8daf92d", null ],
    [ "GPIO_Pin", "structGPIO__InitTypeDef.html#a15699fc7e215ac2579cd24ca76cd4591", null ],
    [ "GPIO_PuPd", "structGPIO__InitTypeDef.html#aeb0168ffc465346d21f3120aec320b72", null ],
    [ "GPIO_Speed", "structGPIO__InitTypeDef.html#a57b08335216f50618ebc080e4fbb0a80", null ]
];