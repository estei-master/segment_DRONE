var structRCC__ClocksTypeDef =
[
    [ "HCLK_Frequency", "structRCC__ClocksTypeDef.html#a5f9bf60f522a160aa7a878acf92ce129", null ],
    [ "PCLK1_Frequency", "structRCC__ClocksTypeDef.html#a9045b24904bde572d479e85c6d2801f6", null ],
    [ "PCLK2_Frequency", "structRCC__ClocksTypeDef.html#a45ada83b2d388a60ed994451f260f389", null ],
    [ "SYSCLK_Frequency", "structRCC__ClocksTypeDef.html#a48b5f04759728e39921969e75c4899e8", null ]
];