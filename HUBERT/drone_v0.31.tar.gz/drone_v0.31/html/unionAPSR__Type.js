var unionAPSR__Type =
[
    [ "_reserved0", "unionAPSR__Type.html#ac8a6a13838a897c8d0b8bc991bbaf7c1", null ],
    [ "_reserved1", "unionAPSR__Type.html#a959a73d8faee56599b7e792a7c5a2d16", null ],
    [ "b", "unionAPSR__Type.html#a2e5b85cff450c7f92c7388dd09f10065", null ],
    [ "C", "unionAPSR__Type.html#a7a1caf92f32fe9ebd8d1fe89b06c7776", null ],
    [ "GE", "unionAPSR__Type.html#aa91800ec6e90e457c7a1acd1f2e17099", null ],
    [ "N", "unionAPSR__Type.html#abae0610bc2a97bbf7f689e953e0b451f", null ],
    [ "Q", "unionAPSR__Type.html#a65f27ddc4f7e09c14ce7c5211b2e000a", null ],
    [ "V", "unionAPSR__Type.html#acd4a2b64faee91e4a9eef300667fa222", null ],
    [ "w", "unionAPSR__Type.html#ad0fb62e7a08e70fc5e0a76b67809f84b", null ],
    [ "Z", "unionAPSR__Type.html#a5ae954cbd9986cd64625d7fa00943c8e", null ]
];