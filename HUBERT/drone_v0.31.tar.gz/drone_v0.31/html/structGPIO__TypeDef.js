var structGPIO__TypeDef =
[
    [ "AFR", "structGPIO__TypeDef.html#ab67c1158c04450d19ad483dcd2192e43", null ],
    [ "BSRRH", "structGPIO__TypeDef.html#a35f89f65edca7ed58738166424aeef48", null ],
    [ "BSRRL", "structGPIO__TypeDef.html#aa79204c9bcc8c481da0a5ffe7c74d8b0", null ],
    [ "IDR", "structGPIO__TypeDef.html#a328d2fe9ef1d513c3a97d30f98f0047c", null ],
    [ "LCKR", "structGPIO__TypeDef.html#a2612a0f4b3fbdbb6293f6dc70105e190", null ],
    [ "MODER", "structGPIO__TypeDef.html#a2b671a94c63a612f81e0e9de8152d01c", null ],
    [ "ODR", "structGPIO__TypeDef.html#abff7fffd2b5a718715a130006590c75c", null ],
    [ "OSPEEDR", "structGPIO__TypeDef.html#a328d16cc6213783ede54e4059ffd50a3", null ],
    [ "OTYPER", "structGPIO__TypeDef.html#a9543592bda60cb5261075594bdeedac9", null ],
    [ "PUPDR", "structGPIO__TypeDef.html#abeed38529bd7b8de082e490e5d4f1727", null ]
];