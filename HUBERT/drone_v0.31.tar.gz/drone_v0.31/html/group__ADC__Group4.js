var group__ADC__Group4 =
[
    [ "ADC_ContinuousModeCmd", "group__ADC__Group4.html#ga879d70e9345d35688590938503f961db", null ],
    [ "ADC_DiscModeChannelCountConfig", "group__ADC__Group4.html#ga6eb241ba82d67d1371136c9132083937", null ],
    [ "ADC_DiscModeCmd", "group__ADC__Group4.html#ga1909649d10253ce88d986ffbb94a4be6", null ],
    [ "ADC_EOCOnEachRegularChannelCmd", "group__ADC__Group4.html#ga5316caaa170415ef171c486d8f0bf22d", null ],
    [ "ADC_GetConversionValue", "group__ADC__Group4.html#gaaf74221c285ec5dab5e66baf7bec6bd3", null ],
    [ "ADC_GetMultiModeConversionValue", "group__ADC__Group4.html#ga989f4365b56be99999b8ec096aba2081", null ],
    [ "ADC_GetSoftwareStartConvStatus", "group__ADC__Group4.html#gaf1119583782ecbcec380efcb7eb74883", null ],
    [ "ADC_RegularChannelConfig", "group__ADC__Group4.html#gac531adb577b648d4bb8881f2ed627d52", null ],
    [ "ADC_SoftwareStartConv", "group__ADC__Group4.html#gac1cd466e725595812c1bbfdad2459ff1", null ]
];