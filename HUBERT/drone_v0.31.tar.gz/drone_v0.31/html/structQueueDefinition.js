var structQueueDefinition =
[
    [ "pcHead", "structQueueDefinition.html#a7d7ae71baf9539e4ade463b54147197e", null ],
    [ "pcReadFrom", "structQueueDefinition.html#a89f93906bf3bc6a600cf2a8c08606d47", null ],
    [ "pcTail", "structQueueDefinition.html#a8bc9e31a442a36c633134d81dad7ad1f", null ],
    [ "pcWriteTo", "structQueueDefinition.html#a863fa84a9d1fed859baa798f3ae3edf7", null ],
    [ "uxItemSize", "structQueueDefinition.html#a0380a8f6684f54b7caec84f9c4683785", null ],
    [ "uxLength", "structQueueDefinition.html#a7ec3bc99d2c6f0cbac8f556927bd2890", null ],
    [ "uxMessagesWaiting", "structQueueDefinition.html#a4df0574070ab314745720d558e136dea", null ],
    [ "xRxLock", "structQueueDefinition.html#a64f61d615708a15d9f87b73449357e3c", null ],
    [ "xTasksWaitingToReceive", "structQueueDefinition.html#a3962c65a11b34c178604bcff6720c531", null ],
    [ "xTasksWaitingToSend", "structQueueDefinition.html#ad9e6557a628289c53f38c3bfb6f48a8a", null ],
    [ "xTxLock", "structQueueDefinition.html#aadcd0751eef08e1e5e18e54afaffbc98", null ]
];