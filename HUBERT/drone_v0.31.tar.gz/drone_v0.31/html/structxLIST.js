var structxLIST =
[
    [ "pxIndex", "structxLIST.html#a90dec9c352d343df99d81237f2de2d35", null ],
    [ "uxNumberOfItems", "structxLIST.html#ac1b18253496c816fef57049f1352fabe", null ],
    [ "xListEnd", "structxLIST.html#ae19f18b24e6248ed6e735b69696156c7", null ]
];