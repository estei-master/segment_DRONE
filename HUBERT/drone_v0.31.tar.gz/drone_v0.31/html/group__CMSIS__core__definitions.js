var group__CMSIS__core__definitions =
[
    [ "__CM4_CMSIS_VERSION", "group__CMSIS__core__definitions.html#gacb6f5d2c3271c95d0a02fd06723af25d", null ],
    [ "__CM4_CMSIS_VERSION_MAIN", "group__CMSIS__core__definitions.html#ga90ffc8179476f80347379bfe29639edc", null ],
    [ "__CM4_CMSIS_VERSION_SUB", "group__CMSIS__core__definitions.html#gafc7392964da961a44e916fcff7add532", null ],
    [ "__CORE_CM4_H_DEPENDANT", "group__CMSIS__core__definitions.html#ga65104fb6a96df4ec7f7e72781b561060", null ],
    [ "__CORTEX_M", "group__CMSIS__core__definitions.html#ga63ea62503c88acab19fcf3d5743009e3", null ],
    [ "__I", "group__CMSIS__core__definitions.html#gaf63697ed9952cc71e1225efe205f6cd3", null ],
    [ "__IO", "group__CMSIS__core__definitions.html#gaec43007d9998a0a0e01faede4133d6be", null ],
    [ "__O", "group__CMSIS__core__definitions.html#ga7e25d9380f9ef903923964322e71f2f6", null ]
];