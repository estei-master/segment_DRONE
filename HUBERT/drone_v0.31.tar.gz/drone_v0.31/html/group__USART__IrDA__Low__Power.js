var group__USART__IrDA__Low__Power =
[
    [ "IS_USART_IRDA_MODE", "group__USART__IrDA__Low__Power.html#ga7790838ff8ee71089da2c0e5bceee569", null ],
    [ "USART_IrDAMode_LowPower", "group__USART__IrDA__Low__Power.html#ga00c2635d0e6ca1a5b158f1c1673e862f", null ],
    [ "USART_IrDAMode_Normal", "group__USART__IrDA__Low__Power.html#ga796cd5451deb896741206986bd6d03e6", null ]
];