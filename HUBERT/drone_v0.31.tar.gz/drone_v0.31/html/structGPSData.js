var structGPSData =
[
    [ "ulSignalLvl", "structGPSData.html#a6394e2d17c23e769e4d261172b17a547", null ]
];