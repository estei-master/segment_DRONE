var structxTASK__PARAMTERS =
[
    [ "pcName", "structxTASK__PARAMTERS.html#aa5448dc9631629653ed4da5d3ceb7f54", null ],
    [ "puxStackBuffer", "structxTASK__PARAMTERS.html#a5db00ede8faab54ea3aa065251c8e37b", null ],
    [ "pvParameters", "structxTASK__PARAMTERS.html#a308cef200968d514395c0272c061d3ec", null ],
    [ "pvTaskCode", "structxTASK__PARAMTERS.html#af3147bdf057f9e7cf681674c143c19f0", null ],
    [ "usStackDepth", "structxTASK__PARAMTERS.html#a79bae2c7efe48bf5b050e0b0d9eeed82", null ],
    [ "uxPriority", "structxTASK__PARAMTERS.html#af9efa11aaf2bd2b1e7b0da3991a493c8", null ],
    [ "xRegions", "structxTASK__PARAMTERS.html#a3d1c92865cea10ff47b3bb47d21fc2fc", null ]
];