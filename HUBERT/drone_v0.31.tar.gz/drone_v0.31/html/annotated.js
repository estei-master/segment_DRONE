var annotated =
[
    [ "droneBatteryWrapper", "structdroneBatteryWrapper.html", "structdroneBatteryWrapper" ],
    [ "droneConfig", "structdroneConfig.html", "structdroneConfig" ],
    [ "droneGPSWrapper", "structdroneGPSWrapper.html", "structdroneGPSWrapper" ],
    [ "droneIMUWrapper", "structdroneIMUWrapper.html", "structdroneIMUWrapper" ],
    [ "droneState", "structdroneState.html", "structdroneState" ],
    [ "droneTelemeterWrapper", "structdroneTelemeterWrapper.html", "structdroneTelemeterWrapper" ],
    [ "droneZigbeeWrapper", "structdroneZigbeeWrapper.html", "structdroneZigbeeWrapper" ],
    [ "flightCommand", "structflightCommand.html", "structflightCommand" ],
    [ "flightMovement", "structflightMovement.html", "structflightMovement" ],
    [ "GPSData", "structGPSData.html", "structGPSData" ],
    [ "IMUData", "structIMUData.html", "structIMUData" ],
    [ "PIDParam", "structPIDParam.html", "structPIDParam" ],
    [ "telemeterData", "structtelemeterData.html", "structtelemeterData" ],
    [ "zigbeeCommandParam", "unionzigbeeCommandParam.html", "unionzigbeeCommandParam" ],
    [ "zigbeeData", "structzigbeeData.html", "structzigbeeData" ]
];