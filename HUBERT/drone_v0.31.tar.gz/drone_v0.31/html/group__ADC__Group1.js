var group__ADC__Group1 =
[
    [ "ADC_Cmd", "group__ADC__Group1.html#ga40882d399e3371755ed610c1134e634e", null ],
    [ "ADC_CommonInit", "group__ADC__Group1.html#ga5803f6581a9cd7e90b6e637067102d94", null ],
    [ "ADC_CommonStructInit", "group__ADC__Group1.html#gad60a6414b4932c704f6f7a7c2963fa2a", null ],
    [ "ADC_DeInit", "group__ADC__Group1.html#ga1962afdd9eebe5c896bbba2e4f26fe09", null ],
    [ "ADC_Init", "group__ADC__Group1.html#gabbab6038cf8691404350625e477254f9", null ],
    [ "ADC_StructInit", "group__ADC__Group1.html#ga6c6e754d1d0a98d56e465efaf73272ec", null ]
];