var group__DMA__Private__Functions =
[
    [ "Data Counter functions", "group__DMA__Group2.html", "group__DMA__Group2" ],
    [ "Double Buffer mode functions", "group__DMA__Group3.html", "group__DMA__Group3" ],
    [ "Initialization and Configuration functions", "group__DMA__Group1.html", "group__DMA__Group1" ],
    [ "Interrupts and flags management functions", "group__DMA__Group4.html", "group__DMA__Group4" ]
];