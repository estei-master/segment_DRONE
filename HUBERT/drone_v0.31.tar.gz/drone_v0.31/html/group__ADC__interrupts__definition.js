var group__ADC__interrupts__definition =
[
    [ "ADC_IT_AWD", "group__ADC__interrupts__definition.html#ga2f5c7f9900c24250a0c6ccaa7cbca946", null ],
    [ "ADC_IT_EOC", "group__ADC__interrupts__definition.html#ga0ad335d835f54415194d448019569e00", null ],
    [ "ADC_IT_JEOC", "group__ADC__interrupts__definition.html#gad439fc0cd69706704d47aeabfeddb631", null ],
    [ "ADC_IT_OVR", "group__ADC__interrupts__definition.html#gac3852b7789860e0ea79b82115ab877a0", null ],
    [ "IS_ADC_IT", "group__ADC__interrupts__definition.html#gaf5f8d35930becff402eeb8220641432f", null ]
];