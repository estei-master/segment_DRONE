var group__USART__Group2 =
[
    [ "USART_ReceiveData", "group__USART__Group2.html#gac67a91845b0b1d54d31bdfb1c5e9867c", null ],
    [ "USART_SendData", "group__USART__Group2.html#ga0b43d42da9540f446d494bf69823c6fb", null ]
];