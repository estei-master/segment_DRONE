var group__ADC__regular__rank =
[
    [ "IS_ADC_REGULAR_RANK", "group__ADC__regular__rank.html#ga5928a1e9315f798e27220b91f1bae7f2", null ]
];