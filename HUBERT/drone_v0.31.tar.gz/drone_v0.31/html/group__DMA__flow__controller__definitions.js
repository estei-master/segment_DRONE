var group__DMA__flow__controller__definitions =
[
    [ "DMA_FlowCtrl_Memory", "group__DMA__flow__controller__definitions.html#gafe69109789c2c285f98193f4b598cbc1", null ],
    [ "DMA_FlowCtrl_Peripheral", "group__DMA__flow__controller__definitions.html#ga33a735d51a2b790a25c579753edddd46", null ],
    [ "IS_DMA_FLOW_CTRL", "group__DMA__flow__controller__definitions.html#ga78c0f18c0a86c67510f540a4210aadb7", null ]
];