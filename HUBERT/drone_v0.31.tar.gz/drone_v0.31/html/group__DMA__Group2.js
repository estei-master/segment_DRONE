var group__DMA__Group2 =
[
    [ "DMA_GetCurrDataCounter", "group__DMA__Group2.html#ga4a76444a92423f5f15a4328738d6dc46", null ],
    [ "DMA_SetCurrDataCounter", "group__DMA__Group2.html#ga6a11a2c951cff59b125ba8857d44e3f3", null ]
];