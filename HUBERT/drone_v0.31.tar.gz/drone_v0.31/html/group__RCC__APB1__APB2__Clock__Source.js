var group__RCC__APB1__APB2__Clock__Source =
[
    [ "IS_RCC_PCLK", "group__RCC__APB1__APB2__Clock__Source.html#gab70f1257ea47c1da4def8e351af4d9f2", null ],
    [ "RCC_HCLK_Div1", "group__RCC__APB1__APB2__Clock__Source.html#gae62b4a39ae69cc221f2ab7d4518bfb76", null ],
    [ "RCC_HCLK_Div16", "group__RCC__APB1__APB2__Clock__Source.html#ga6353aaa0b302fdd5d946fd21756e2273", null ],
    [ "RCC_HCLK_Div2", "group__RCC__APB1__APB2__Clock__Source.html#ga177bb3648def9a961c16f93f15ca0f62", null ],
    [ "RCC_HCLK_Div4", "group__RCC__APB1__APB2__Clock__Source.html#gafd8cf0e32a3ea5648cdc054766bc2017", null ],
    [ "RCC_HCLK_Div8", "group__RCC__APB1__APB2__Clock__Source.html#gab2e2b6e0b8fe22d6638b672918b22097", null ]
];