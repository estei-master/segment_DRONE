var structDMA__InitTypeDef =
[
    [ "DMA_BufferSize", "structDMA__InitTypeDef.html#ad5e4b9069a7a145b3312d54d09059f78", null ],
    [ "DMA_Channel", "structDMA__InitTypeDef.html#afae070f2d49543b1acd3e318c6de8527", null ],
    [ "DMA_DIR", "structDMA__InitTypeDef.html#a4cf4283185065f65d5a63089877cbb8d", null ],
    [ "DMA_FIFOMode", "structDMA__InitTypeDef.html#a684555f9f5644259b7c4ca446b6dcf8f", null ],
    [ "DMA_FIFOThreshold", "structDMA__InitTypeDef.html#a2bbb3ea272279aa5cddef702e153a09d", null ],
    [ "DMA_Memory0BaseAddr", "structDMA__InitTypeDef.html#aebf1267410908265f83a8037245c337e", null ],
    [ "DMA_MemoryBurst", "structDMA__InitTypeDef.html#a90987eb939726acf365f2bf039a51725", null ],
    [ "DMA_MemoryDataSize", "structDMA__InitTypeDef.html#a7ec1648d136d31d6c504565bf6949eb6", null ],
    [ "DMA_MemoryInc", "structDMA__InitTypeDef.html#ad8f8a0f3ba4db5d79fd78d02093e4eb9", null ],
    [ "DMA_Mode", "structDMA__InitTypeDef.html#a5f09c16a03a50120c1a1a49ae6a7c667", null ],
    [ "DMA_PeripheralBaseAddr", "structDMA__InitTypeDef.html#ad02abd574cca0caeacd0cc05d2174a42", null ],
    [ "DMA_PeripheralBurst", "structDMA__InitTypeDef.html#a6772e281310a3e93781364c723984138", null ],
    [ "DMA_PeripheralDataSize", "structDMA__InitTypeDef.html#a61bf939d8657d44a9beb1daa91c14668", null ],
    [ "DMA_PeripheralInc", "structDMA__InitTypeDef.html#ad0bf5e8b3968eaf8dc18e923b94acfe1", null ],
    [ "DMA_Priority", "structDMA__InitTypeDef.html#aabb62e3f5536fc15a201058a1b6bda18", null ]
];