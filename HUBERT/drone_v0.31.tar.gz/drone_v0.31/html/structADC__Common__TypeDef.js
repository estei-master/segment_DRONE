var structADC__Common__TypeDef =
[
    [ "CCR", "structADC__Common__TypeDef.html#a5e1322e27c40bf91d172f9673f205c97", null ],
    [ "CDR", "structADC__Common__TypeDef.html#a760f86a1a18dffffda54fc15a977979f", null ],
    [ "CSR", "structADC__Common__TypeDef.html#a876dd0a8546697065f406b7543e27af2", null ]
];